# PDF to Image to JSON

Converts a PDF into page images (saved in the `images` folder), reads each image
with OCR, and writes the key details (patient name, DOB, phone, physician, fax
details, etc.) to `output.json`.

## Requirements

- Windows 10/11
- Python 3.10+

## Install (one time)

Open PowerShell and run:

```powershell
# 1. Python packages
pip install pdf2image pytesseract pillow

# 2. Poppler (turns PDF pages into images)
winget install oschwartz10612.Poppler

# 3. Tesseract (reads the text from images)
winget install UB-Mannheim.TesseractOCR
```

If winget asks you to agree to the terms, type `Y` and press Enter.

The script finds Poppler and Tesseract in their default install folders, so you
do not need to edit PATH. Check that they installed:

```powershell
winget list Poppler
winget list Tesseract
```

## Run

From the project folder:

```powershell
cd D:\Projects\pdftoimage
python pdftoimg.py
```

This reads `thomas.pdf` and writes `output.json`.

### Other ways to run

| Command | What it does |
| --- | --- |
| `python pdftoimg.py other.pdf` | Use a different PDF |
| `python pdftoimg.py other.pdf -o other.json` | Use a different PDF and output file |
| `python pdftoimg.py --skip-pdf` | Skip the PDF step and read the images already in `images` |
| `python pdftoimg.py --raw` | Also include the full recognized text in the JSON (useful when a field is missed) |
| `python pdftoimg.py --images-dir scans` | Use a different images folder |

## Output

One entry per image:

```json
[
  {
    "image": "thomas_2.png",
    "fields": {
      "patient_name": "THOMAS, MURLENE",
      "dob": "06/05/1938",
      "city": "LAWTON"
    }
  }
]
```

## Adding or fixing fields

Open `pdftoimg.py` and edit the `FIELDS` list near the top. Each field has one or
more patterns that match its label on the page. Run with `--raw` to see the
recognized text and write a pattern for the label you need.

## Common errors

| Error | Fix |
| --- | --- |
| `PDFInfoNotInstalledError` | Poppler is missing. Run the Poppler install above. |
| `TesseractNotFoundError` | Tesseract is missing. Run the Tesseract install above. |
| A field is missing from the JSON | Its label is not in `FIELDS`. See "Adding or fixing fields". |

## Privacy

`images/` and `output.json` contain patient data. Delete them or store them
securely when you are done.
