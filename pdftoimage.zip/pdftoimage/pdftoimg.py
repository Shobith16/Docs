"""PDF -> images folder -> OCR each image -> JSON of the key details.

Usage:
    python pdftoimg.py                      # converts thomas.pdf, writes output.json
    python pdftoimg.py some.pdf -o out.json
    python pdftoimg.py --skip-pdf           # OCR images already in the images folder
"""
import argparse
import glob
import json
import os
import re
import shutil

import pytesseract
from pdf2image import convert_from_path
from PIL import Image

IMAGE_DIR = "images"


# Tesseract / Poppler locations used when they are not on PATH
if not shutil.which("tesseract"):
    for exe in (os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
        if os.path.exists(exe):
            pytesseract.pytesseract.tesseract_cmd = exe
            break

POPPLER_PATH = None
if not shutil.which("pdfinfo"):
    for pattern in (
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\oschwartz10612.Poppler*\poppler-*\Library\bin"),
        r"C:\poppler*\Library\bin",
        r"C:\poppler*\bin",
        r"C:\Program Files\poppler*\Library\bin",
    ):
        hits = glob.glob(pattern)
        if hits:
            POPPLER_PATH = hits[0]
            break


# ---------------------------------------------------------------- PDF -> images
def pdf_to_images(pdf_path, out_dir=IMAGE_DIR, dpi=300):
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(pdf_path))[0]
    pages = convert_from_path(pdf_path, dpi=dpi, poppler_path=POPPLER_PATH)
    paths = []
    for i, page in enumerate(pages, 1):
        path = os.path.join(out_dir, f"{base}_{i}.png")
        page.save(path, "PNG")
        paths.append(path)
        print(f"Saved: {path}")
    return paths


# ---------------------------------------------------------------- field rules
# Layouts differ between PDFs, so each field has one or more label patterns;
# the first that matches wins. Add or edit entries here to pick up new items.
DATE = r"(\d{1,2}/\d{1,2}/\d{2,4})"
FIELDS = {
    "patient_name": [r"Patient\s*:\s*(.+?)(?:\s{2,}|\s+Insured|$)"],
    "mr_no":        [r"\bMR\s*No\s*:\s*([A-Z0-9\-]+)"],
    "insured_id":   [r"Insured\s*ID\s*:\s*([A-Z0-9]+)"],
    "primary_payor":[r"Primary\s*Payor\s*:\s*(\S+)"],
    "dob":          [r"\bDOB\s*:?\s*" + DATE],
    "gender":       [r"\bGender\s*:?\s*(Male|Female)"],
    "ssn":          [r"\bSSN\s*:?\s*([\dXx*]{3}-[\dXx*]{2}-[\dXx*]{4})"],
    # value printed on the line below its label: "Street City State Zip County"
    "patient_phone":[r"Phone\s+MSA[^\n]*\n\s*(\(\d{3}\)\s?\d{3}-\d{4})"],
    "sender_phone": [r"\bPhone\s*:\s*(\d{3}-\d{3}-\d{4})"],
    "address":      [r"Street\s+City\s+State\s+Zip[^\n]*\n\s*(\d+.+?)\s+[A-Z][A-Za-z ]+\s+[A-Z]{2}\s+\d{5}"],
    "city":         [r"Street\s+City\s+State\s+Zip[^\n]*\n\s*\d+.+?\s+([A-Z][A-Za-z ]+?)\s+[A-Z]{2}\s+\d{5}"],
    "state":        [r"Street\s+City\s+State\s+Zip[^\n]*\n\s*\d+.+?\s+([A-Z]{2})\s+\d{5}"],
    "zip":          [r"Street\s+City\s+State\s+Zip[^\n]*\n\s*\d+.+?\s+[A-Z]{2}\s+(\d{5})"],
    "referral_date":[r"Referral\s*Date\s*:?\s*" + DATE],
    "referral_type":[r"Referral\s*Type\s*:?\s*([A-Za-z ]+?)(?:\s{2,}|\s+Referral|$)"],
    "primary_physician": [r"Primary\s*Physician[^\n]*\n\s*([A-Z][A-Z ,.'\-]+?)(?:\s+\d{10}|\s*$)"],
    "npi":          [r"Primary\s*Physician[^\n]*\n[^\n]*?(\d{10})", r"NPI\s*#?\s*:?\s*(\d{10})"],
    "fax_to":       [r"\bTo\s*:\s*(.+?)(?:\s{2,}|\s+From\s*:|$)"],
    "fax_from":     [r"\bFrom\s*:\s*(.+)"],
    "fax_number":   [r"\bFax\s*:\s*(\d{7,})"],
    "fax_pages":    [r"\bPages\s*:\s*(\d+)"],
    "fax_date":     [r"\bDate\s*:\s*(\d{1,2}-\d{1,2}-\d{4}\s+[\d:]+\s*[AP]M)"],
}


def extract_fields(text):
    found = {}
    for name, patterns in FIELDS.items():
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE | re.MULTILINE)
            if m and m.group(1).strip():
                found[name] = re.sub(r"\s+", " ", m.group(1)).strip(" :,")
                break
    return found


def address_by_columns(path):
    """Split the 'Street / City / State / Zip' row using the header's x positions."""
    d = pytesseract.image_to_data(Image.open(path).convert("L"), config="--psm 6",
                                  output_type=pytesseract.Output.DICT)
    words = [(d["text"][i].strip(), d["left"][i], d["top"][i], d["height"][i])
             for i in range(len(d["text"])) if d["text"][i].strip()]
    for i, (w, x, y, h) in enumerate(words):
        if w != "Street":
            continue
        row = [t for t in words if abs(t[2] - y) < h]
        xs = {t[0]: t[1] for t in row}
        if not {"City", "State", "Zip"} <= xs.keys():
            continue
        below = sorted((t for t in words if h * 0.5 < t[2] - y < h * 3), key=lambda t: t[1])
        cut = lambda lo, hi: " ".join(t[0] for t in below if lo - 5 <= t[1] < hi - 5)
        return {
            "address": cut(xs["Street"], xs["City"]),
            "city": cut(xs["City"], xs["State"]),
            "state": cut(xs["State"], xs["Zip"]),
            "zip": re.sub(r"\D+$", "", cut(xs["Zip"], xs["Zip"] + 400).split(" ")[0]),
        }
    return {}


def ocr_image(path):
    img = Image.open(path).convert("L")
    # psm 6 keeps each printed line together, which suits label/value forms
    return pytesseract.image_to_string(img, config="--psm 6")


def process_folder(folder, keep_text=False):
    results = []
    files = sorted(
        f for ext in ("png", "jpg", "jpeg")
        for f in glob.glob(os.path.join(folder, f"*.{ext}"))
    )
    for path in files:
        text = ocr_image(path)
        fields = extract_fields(text)
        fields.update({k: v for k, v in address_by_columns(path).items() if v})
        entry = {"image": os.path.basename(path), "fields": fields}
        if keep_text:
            entry["raw_text"] = text
        results.append(entry)
        print(f"OCR done: {path} ({len(entry['fields'])} fields)")
    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf", nargs="?", default="thomas.pdf")
    ap.add_argument("-o", "--output", default="output.json")
    ap.add_argument("--images-dir", default=IMAGE_DIR)
    ap.add_argument("--skip-pdf", action="store_true", help="only OCR images already in the folder")
    ap.add_argument("--raw", action="store_true", help="include raw OCR text in the JSON")
    args = ap.parse_args()

    if not args.skip_pdf:
        pdf_to_images(args.pdf, args.images_dir)

    data = process_folder(args.images_dir, keep_text=args.raw)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(json.dumps(data, indent=2, ensure_ascii=False))
